/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "OLED128x64.h"
#include "peripheral/tc/plib_tc0.h"
#include <stdio.h>

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
#define         ADDR_MCP9800A5   0x4d
#define         VEML7700_ADDR   0x10 
#define         WRITE_ID(id)    (id << 18)
#define         READ_ID(id)     (id >> 18)
#define         CAN_TXID        0x300 
#define         CAN_RXID        0x200

uint8_t Can0MessageRAM[CAN0_MESSAGE_RAM_CONFIG_SIZE] __attribute__((aligned (32)));

static uint8_t      txFiFo[CAN0_TX_FIFO_BUFFER_SIZE];
static uint8_t      rxFiFo0[CAN0_RX_FIFO0_SIZE];
volatile bool       bIsI2C_DONE = 1 ;
volatile bool       bIsTimeout = 0;

unsigned int    VR_Result = 0 ;
unsigned char   ASCII_Buf[32] ;
unsigned char   I2C_wData[16];
unsigned char   I2C_rData[16];
unsigned int    LoopCounter=0;
unsigned int    LightingValue ;
uint16_t        ADC_From_CAN ;

unsigned char   RGB_State = 0 ;

static uint8_t CANLengthToDlcGet(uint8_t);
void    Transmit_CAN0_Message(void);
uint16_t Receive_CAN_Message(void);

void    TC0_ISR(TC_TIMER_STATUS status, uintptr_t contest)
{
    LED1_Toggle();
    bIsTimeout = 1 ;
}

void    I2C_EventHandler(uintptr_t  contest)
{
    if (SERCOM0_I2C_ErrorGet() == SERCOM_I2C_ERROR_NONE )
        bIsI2C_DONE = true ;
}


int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    TC0_TimerCallbackRegister(TC0_ISR, (uintptr_t)NULL) ;
    SERCOM0_I2C_CallbackRegister(I2C_EventHandler,0) ;
    CAN0_MessageRAMConfigSet(Can0MessageRAM);                   // Important ... To allocate correct RAM Buffer for CAN Buffers 
    TC0_TimerStart();
    ADC0_Enable();
    while (bIsTimeout ==0) ;
    bIsTimeout = 0 ;
    
//  ADC0_ChannelSelect(ADC_POSINPUT_AIN6,ADC_NEGINPUT_GND);
    
            bIsI2C_DONE = false ;
            I2C_wData[0] = 0x01 ;
            I2C_wData[1] = 0b01100000 ;
            SERCOM0_I2C_Write(ADDR_MCP9800A5, I2C_wData, 2);
            while (bIsI2C_DONE == false);
            
    // Activate Lighting Sensor
        bIsI2C_DONE = false ;
        I2C_wData[0] = 0x00 ;
        I2C_wData[1] = 0x00 ;
        I2C_wData[2] = 0x18 ;
        SERCOM0_I2C_Write(VEML7700_ADDR, I2C_wData, 3);          
        while (bIsI2C_DONE == false);         
    
        OLED_Init();
        OLED_CLS();
        OLED_Put8x16Str(0, 0, (const unsigned char*) "APP-ESS-2025 EVB") ;    
        OLED_Put8x16Str(0, 2, (const unsigned char*) " PIC32CM5164JH") ;           
    
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
        ADC_From_CAN = Receive_CAN_Message();
            
        if (bIsTimeout)
        {
            bIsTimeout = 0 ;
            Transmit_CAN0_Message();
            if (GPIO_SW2_Get())
            {
                GPIO_RED_Clear();
                GPIO_GREEN_Clear();
                GPIO_BLUE_Clear();
                RGB_State = 0 ;                
            }
            else
            {
                switch (RGB_State)
                {
                    case    0:
                        GPIO_RED_Set();
                        GPIO_GREEN_Clear();
                        GPIO_BLUE_Clear();                    
                        RGB_State++ ;
                        break;
                    case 1:
                        GPIO_RED_Clear();
                        GPIO_GREEN_Set();
                        GPIO_BLUE_Clear();                    
                        RGB_State++ ;
                        break;
                    case 2:
                        GPIO_RED_Clear();
                        GPIO_GREEN_Clear();
                        GPIO_BLUE_Set();                    
                        RGB_State = 0 ;
                        break;
                    default:
                        GPIO_RED_Set();
                        GPIO_GREEN_Set();
                        GPIO_BLUE_Set();
                        RGB_State = 0 ;
                        break ;
                }
            }    
            
            printf ("Hello Microchip %5d\n\r", LoopCounter++);
            //  Read MCP9800 and Display
            bIsI2C_DONE = false ;
            I2C_wData[0] = 0x00 ;
            SERCOM0_I2C_WriteRead(ADDR_MCP9800A5,I2C_wData,1,I2C_rData,2);
            while (bIsI2C_DONE == false) ;
            
            sprintf ((char*)ASCII_Buf,"T:%2.2f",(float)(I2C_rData[0]*256+I2C_rData[1])/256);
            OLED_Put8x16Str(0,4,(const unsigned char*)ASCII_Buf);
            
            // Read Lighting Sensor
                bIsI2C_DONE = false ;
                I2C_wData[0] = 4 ;
                SERCOM0_I2C_WriteRead(VEML7700_ADDR,I2C_wData,1,I2C_rData,2);
                while (bIsI2C_DONE == false) ;                               
                LightingValue = I2C_rData[0] + (I2C_rData[1]) * 256;          
                
            sprintf ((char*)ASCII_Buf,"L:%5d",LightingValue);
            OLED_Put8x16Str(72,4,(const unsigned char*)ASCII_Buf);    
            
            // Read VR and Display ;            
            ADC0_ConversionStart();
            while (!ADC0_ConversionStatusGet())
            {
                ;
            }
            VR_Result = ADC0_ConversionResultGet();
            sprintf ((char*)ASCII_Buf,"AD=%4d ADI=%4d",VR_Result, ADC_From_CAN);
            OLED_Put8x16Str(0,6,(const unsigned char*)ASCII_Buf);
        }
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}

uint16_t Receive_CAN_Message(void)
{
    CAN_RX_BUFFER *rxBuffer = NULL; 
    uint8_t        numberOfMessage = 0; 
    static uint32_t     CANStatus = 0;
    static uint32_t     ReceivedID  ;
    uint16_t            ReturnValue = 0 ;
    
      if (CAN0_InterruptGet(CAN_INTERRUPT_RF0N_MASK))
        {    
            CAN0_InterruptClear(CAN_INTERRUPT_RF0N_MASK);

            /* Check CAN Status */
            CANStatus = CAN0_ErrorGet();
            if (((CANStatus & CAN_PSR_LEC_Msk) == CAN_ERROR_NONE) || ((CANStatus & CAN_PSR_LEC_Msk) == CAN_ERROR_LEC_NC))
            {
                numberOfMessage = CAN0_RxFifoFillLevelGet(CAN_RX_FIFO_0);
                if (numberOfMessage != 0)
                {
                    memset(rxFiFo0, 0x00, (numberOfMessage * CAN0_RX_FIFO0_ELEMENT_SIZE));
                    // if (CAN0_MessageReceiveFifo(CAN_RX_FIFO_0, numberOfMessage, (CAN_RX_BUFFER *)rxFiFo) == true)
                    // CAN0 : Read Buffer one by one 
                    if (CAN0_MessageReceiveFifo(CAN_RX_FIFO_0, 1, (CAN_RX_BUFFER *)rxFiFo0) == true)
                    {
                        rxBuffer = (CAN_RX_BUFFER *)rxFiFo0;     
                            ReceivedID = READ_ID(rxBuffer->id);                                                               
                            if (ReceivedID == CAN_RXID)
                            {
                                    LED2_Toggle();
                                    ReturnValue = ((uint16_t) rxBuffer->data[3] * 256 )+ rxBuffer->data[2] ;
                            }
                            else    ReturnValue = 0 ;
                    }

                }
            }
        }
    return (ReturnValue);
}

static uint8_t CANLengthToDlcGet(uint8_t length)
{
    uint8_t dlc = 0;

    if (length <= 8U)
    {
        dlc = length;
    }
    else if (length <= 12U)
    {
        dlc = 0x9U;
    }
    else if (length <= 16U)
    {
        dlc = 0xAU;
    }
    else if (length <= 20U)
    {
        dlc = 0xBU;
    }
    else if (length <= 24U)
    {
        dlc = 0xCU;
    }
    else if (length <= 32U)
    {
        dlc = 0xDU;
    }
    else if (length <= 48U)
    {
        dlc = 0xEU;
    }
    else
    {
        dlc = 0xFU;
    }
    return dlc;
}

void    Transmit_CAN0_Message(void)
{
     CAN_TX_BUFFER *txBuffer = NULL;    
    
                // CAN0 : Transfer 8 bytes data to CAN Bus 
                memset(txFiFo, 0x00, CAN0_TX_FIFO_BUFFER_ELEMENT_SIZE);
                txBuffer = (CAN_TX_BUFFER *)txFiFo;
                txBuffer->id = WRITE_ID(CAN_TXID);
                txBuffer->dlc = CANLengthToDlcGet(8);
                txBuffer->fdf = 0 ;
                txBuffer->brs = 0 ;
                
                txBuffer->data[0] = 0x55; // Low byte of ADC_Buffer
                txBuffer->data[1] = 0xaa; // High byte of ADC_Buffer
                txBuffer->data[2] = VR_Result%256 ;
                txBuffer->data[3] = VR_Result/256 ;
                txBuffer->data[4] = 0;
                txBuffer->data[5] = 0;
                txBuffer->data[6] = 0;
                txBuffer->data[7] = 0;
                
                if (CAN0_TxFifoFreeLevelGet())
                {
                 CAN0_MessageTransmitFifo(1, txBuffer);   
                }    
}


/*******************************************************************************
 End of File
*/

